import './hero/frontend';
import './slideshow/frontend';