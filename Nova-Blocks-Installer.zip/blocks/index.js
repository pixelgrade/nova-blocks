import "./hero";
import "./media";
import "./slideshow";

import "../assets/scss/style.scss";
